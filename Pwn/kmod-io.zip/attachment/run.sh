#!/bin/sh
# A7 kmod-io（煤炭矿开采·采集节点寄存器窗口驱动）—— 本地复现启动脚本。
#
#   你的 TCP 客户端  <->  socat（同一时刻只服务一个连接）  <->  QEMU 串口 unix socket
#                     <->  guest ttyS0  <->  iod  <->  /dev/iodev
#
# 与线上同款的 QEMU 参数：-m 256M -smp 1 -cpu qemu64（TCG，无需 KVM），
# 内核参数 console=ttyS0 quiet loglevel=0 panic=1 oops=panic。
#
# 注意：本包 guest 里的 /flag 是占位串（本地自测用），真值只在线上环境。
#
# 用法：
#   ./run.sh                 # 在本目录（含 bzImage / initramfs.cpio.gz）执行
#   PORT=1517 ./run.sh       # 换监听端口
#   连上后：nc 127.0.0.1 1517   （或用自己的脚本）
set -eu

PORT=${PORT:-1517}
SOCK=${SOCK:-/tmp/field.sock}
GUEST=${GUEST:-$(cd "$(dirname "$0")" && pwd)}
rm -f "$SOCK"

qemu-system-x86_64 \
	-m 256M -smp 1 -cpu qemu64 \
	-kernel "$GUEST/bzImage" \
	-initrd "$GUEST/initramfs.cpio.gz" \
	-append "console=ttyS0 quiet loglevel=0 panic=1 oops=panic" \
	-display none -monitor none \
	-serial unix:$SOCK,server=on,wait=off &

for _ in $(seq 1 200); do
	[ -S "$SOCK" ] && break
	sleep 0.1
done

while :; do
	socat TCP-LISTEN:"$PORT",reuseaddr,bind=0.0.0.0 UNIX-CONNECT:"$SOCK" || true
	sleep 0.2
done
