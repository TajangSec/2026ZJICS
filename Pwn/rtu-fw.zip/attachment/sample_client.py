#!/usr/bin/env python3
"""A2 rtu-fw —— 主站侧极简示例客户端。

用法：python3 sample_client.py <host> <port>

链路帧：05 64 LEN CTRL DEST(2) SRC(2) CRC(2) <用户数据>
        LEN = 5 + len(用户数据)；用户数据每 16 字节追加 2 字节 CRC-16/DNP
        用户数据 = 传输层(0xC0…) + 应用层（FC 0x01 读 / FC 0xC0 厂家标定）
"""
import socket
import sys

DEST_OUTSTATION, SRC_MASTER, FC_READ, FC_VENDOR_CAL = 3, 1, 0x01, 0xC0
BANNER_MARK = b"awaiting master"


def crc16_dnp(data):
    crc = 0                      # poly 0x3D65(反射 0xA6BC), init 0, xorout 0xFFFF
    for b in data:
        crc ^= b
        for _ in range(8):
            crc = (crc >> 1) ^ 0xA6BC if crc & 1 else crc >> 1
    return (~crc) & 0xFFFF


def leb128(v):
    out = bytearray()
    while True:
        out.append((v & 0x7F) | (0x80 if v >> 7 else 0))
        v >>= 7
        if not v:
            return bytes(out)


def ll_frame(dest, src, user, ctrl=0xC4):
    hdr = bytes([5, 0x64, 5 + len(user), ctrl, dest & 0xFF, dest >> 8, src & 0xFF, src >> 8])
    crc = crc16_dnp(hdr)
    out = bytearray(hdr + bytes([crc & 0xFF, crc >> 8]))
    for i in range(0, len(user), 16):
        blk = user[i:i + 16]
        crc = crc16_dnp(blk)
        out += blk + bytes([crc & 0xFF, crc >> 8])
    return bytes(out)


def read_request(qualifier=0x06, count=0, objects=b""):
    """FC 0x01：qualifier=0x06 为整组召唤；0x07 为显式点列表（count + 对象）。"""
    app = bytes([0xC0, FC_READ, 60, 1, qualifier])
    if qualifier == 0x07:
        app += bytes([count & 0xFF]) + objects
    return ll_frame(DEST_OUTSTATION, SRC_MASTER, b"\xC0" + app)


def vendor_request(sub, count, objects=b""):
    """FC 0xC0：厂家标定 / 私有子功能。"""
    app = bytes([0xC0, FC_VENDOR_CAL, sub & 0xFF, count & 0xFF]) + objects
    return ll_frame(DEST_OUTSTATION, SRC_MASTER, b"\xC0" + app)


def drain(s, secs=1.0):
    s.settimeout(secs)
    out = b""
    try:
        while True:
            chunk = s.recv(4096)
            if not chunk:
                break
            out += chunk
    except socket.timeout:
        pass
    return out


def main():
    if len(sys.argv) < 3:
        print("用法: python3 sample_client.py <host> <port>")
        return 2
    s = socket.create_connection((sys.argv[1], int(sys.argv[2])), timeout=5)
    banner = drain(s, 3.0)                           # 等设备就绪（带超时，设备静默也不挂死）
    print(banner.decode("latin-1", "replace").rstrip())
    if BANNER_MARK not in banner:
        print("(未在 3s 内看到设备横幅；继续尝试发送)", file=sys.stderr)

    s.sendall(read_request())                        # 整组召唤（qualifier 0x06）
    reply = drain(s)
    print("reply(text):", reply.decode("latin-1", "replace").strip())
    print("reply(hex):", reply.hex())
    s.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
